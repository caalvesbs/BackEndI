package com.uniesp.aulas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulasApplicationTests {

	@Test
	void contextLoads() {
	}

}
